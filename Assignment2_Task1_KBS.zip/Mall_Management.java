
public class Mall_Management {
    public static void main(String[] args) {
        clothing_store cloths = new clothing_store("Fashion", "3rd Floor", "10am-5pm", "407-933-5033");
        cloths.details();
        electronic_store electrics = new electronic_store("Enlighten", "2nd Floor", "8am-5pm", "407-932-5032");
        electrics.details();
        grocery_store groceries = new grocery_store("All In One", "Ground Floor", "10am-9pm", "407-931-5031");
        groceries.details();

    }
}