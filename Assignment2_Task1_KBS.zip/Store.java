class Store {
    public String storeName;
    public String location;
    public String operating_hours;
    public String contact;

    public Store(String storeName, String location, String operating_hours, String contact) {
        this.storeName = storeName;
        this.location = location;
        this.operating_hours = operating_hours;
        this.contact = contact;
    }

    public void store_details() {
        System.out.println("Store Name: " + storeName);
        System.out.println("Location: " + location);
        System.out.println("Operating Hours: " + operating_hours);
        System.out.println("Contact Information: " + contact);
    }
}

class clothing_store extends Store {
    private String[] clothingName;
    private String[] clothing_brands;
    private double fitting_room;

    public clothing_store(String storeName, String location, String operating_hours, String contact) {
        super(storeName, location, operating_hours, contact);
        this.clothingName = new String[]{"Male", "Female", "Children"};
        this.clothing_brands = new String[]{"Adidas", "Nike", "Puma"};
        this.fitting_room = 5;

    }

    public void details() {
        store_details();
        String clothingName1 = "";
        String clothingBrands = "";
        for (int i = 0; i < this.clothingName.length; i++) {
            clothingName1 = clothingName1 + " " + clothingName[i]+",";
            clothingBrands = clothingBrands + " " + clothing_brands[i] + ",";

        }
        System.out.println("Clothing Categories: " + clothingName1);
        System.out.println("Clothing Brands " + clothingBrands);


        System.out.println("Fitting Rooms: " + fitting_room);
        System.out.println("*___________________*");
    }
}

class electronic_store extends Store {
    private String product_warranty;
    private String technical_support;
    private double testing_area;

    public electronic_store(String storeName, String location, String operating_hours, String contact) {
        super(storeName, location, operating_hours, contact);
        this.product_warranty = "Yes";
        this.technical_support = "Yes";
        this.testing_area = 6;
    }

    public void details() {
        store_details();
        System.out.println("Product Warranty: " + product_warranty);
        System.out.println("Technical Support: " + technical_support);
        System.out.println("Test Area: " + testing_area);
        System.out.println("*___________________*");
    }
}

class grocery_store extends Store {
    private String[] product_categories;
    private String checkout;

    public grocery_store(String storeName, String location, String operating_hours, String contact) {
        super(storeName, location, operating_hours, contact);
        this.product_categories = new String[]{"Cooking wares", "General Food", "Dairy", "Meat Products"};
        this.checkout = "Available";
    }

    public void details() {
        store_details();
        System.out.println("Checkout option: " + checkout);
        for (int i = 1; i < product_categories.length; i++) {
            System.out.println("Product Category: " + product_categories[i]);
        }
        System.out.println("*___________________*");
    }
}

